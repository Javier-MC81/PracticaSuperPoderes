//
//  PracticaSuperPoderesTests.swift
//  PracticaSuperPoderesTests
//
//  Created by JAVIER MORENO CARRERO on 30/3/23.
//

import XCTest
@testable import PracticaSuperPoderes
import SwiftUI
import Combine
import ViewInspector


final class PracticaSuperPoderesTests: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
//    //Test de UI
//
    func testHeroSeriesView() throws {
        let series = HeroesSeriesView(viewModel: HeroSeriesViewModel(testing: true), hero: "Captain Carter")
        
        XCTAssertNotNil(series)
        XCTAssertEqual(series.hero, "Captain Carter")
        
        //número de vistas
        let numItems = try series.inspect().count
        XCTAssertEqual(numItems, 1)
        
        //lista de series
        let list = try series.inspect().find(viewWithId: 0)
        XCTAssertNotNil(list)
        
        let text = series.hero
        XCTAssertEqual(text, "Captain Carter")
        
        
    }
    func testSerieRowView() throws {
        
        let serie = ResultSeries(id: 34322, title: "Captain Carter (2022)", description: "A reality where Agent Peggy Carter took the Super-Soldier Serum is turned upside down when the World War II hero is pulled from the ice where she was lost in action decades before.", startYear: 2022, endYear: 2022, modified: "2022-08-11T14:02:37-0400", thumbnail: Thumbnail(path: "http://i.annihil.us/u/prod/marvel/i/mg/b/40/image_not_available", thumbnailExtension: .jpg))
        let rowSerie = SerieRowView(serie: serie)
        XCTAssertNotNil(rowSerie)
        
        //número de vistas
        let numItems = try rowSerie.inspect().count
        XCTAssertEqual(numItems, 1)
        
        //imagen de la serie
        let img = try rowSerie.inspect().find(viewWithId: 0)
        XCTAssertNotNil(img)
        
        //texto de la descripcion de la serie
        let text = try rowSerie.inspect().find(viewWithId: 1)
        XCTAssertNotNil(text)
        
        let texto = try text.text().string()
        XCTAssertEqual(texto, "A reality where Agent Peggy Carter took the Super-Soldier Serum is turned upside down when the World War II hero is pulled from the ice where she was lost in action decades before.")
        
     
    }
    func testHeroRowView() throws {
        let hero = Result(id: 01, name: "Hit-Monkey", description: "", modified: "2022-05-03T11:41:04-0400", thumbnail: Thumbnail(path: "http://i.annihil.us/u/prod/marvel/i/mg/6/30/4ce69c2246c21", thumbnailExtension: .jpg))
        
        let rowHero = HeroeRowView(hero: hero)
        XCTAssertNotNil(rowHero)
        
        //número de vistas
        let numItems = try rowHero.inspect().count
        XCTAssertEqual(numItems, 1)
        
        //imagen de la serie
        let img = try rowHero.inspect().find(viewWithId: 0)
        XCTAssertNotNil(img)
        
        //texto de la descripcion de la serie
        let text = try rowHero.inspect().find(viewWithId: 1)
        XCTAssertNotNil(text)
        
        let texto = try text.text().string()
        XCTAssertEqual(texto, "Hit-Monkey")
   
    }
    func testHeroListView() throws {
        let list = HeroesListView(viewModel: RootViewModel(testing: true))
        XCTAssertNotNil(list)
        
        
        //número de vistas
        let numItems = try list.inspect().count
        XCTAssertEqual(numItems, 1)
        
        //título de la navegación
        let title = try list.inspect().find(viewWithId: 0)
        XCTAssertNotNil(title)
        
    }

    // Testing de modelos
    func testModels() throws {
        let hero = Result(id: 01, name: "Hit-Monkey", description: "", modified: "2022-05-03T11:41:04-0400", thumbnail: Thumbnail(path: "http://i.annihil.us/u/prod/marvel/i/mg/6/30/4ce69c2246c21", thumbnailExtension: .jpg))
        
        XCTAssertNotNil(hero)
        XCTAssertEqual(hero.name, "Hit-Monkey")
        XCTAssertEqual(hero.id, 01)
        XCTAssertEqual(hero.modified, "2022-05-03T11:41:04-0400")
        
        
        let serie = ResultSeries(id: 34322, title: "Captain Carter (2022)", description: "A reality where Agent Peggy Carter took the Super-Soldier Serum is turned upside down when the World War II hero is pulled from the ice where she was lost in action decades before.", startYear: 2022, endYear: 2022, modified: "2022-08-11T14:02:37-0400", thumbnail: Thumbnail(path: "http://i.annihil.us/u/prod/marvel/i/mg/b/40/image_not_available", thumbnailExtension: .jpg))
        
        XCTAssertNotNil(serie)
        XCTAssertEqual(serie.id, 34322)
        XCTAssertEqual(serie.startYear, 2022)
        XCTAssertEqual(serie.endYear, 2022)
        
    }
    
    
    

}
