//
//  HeroesSeriesView.swift
//  PracticaSuperPoderes
//
//  Created by JAVIER MORENO CARRERO on 28/3/23.
//

import SwiftUI

struct HeroesSeriesView: View {
    
    //Escuchamos los cambios que se produzcan en el viewmodel para reflejarlos en la vista
    @StateObject var viewModel: HeroSeriesViewModel
    
    //Necesito el héroe que protagoniza las series para poner el título en el navegador
    var hero: String
    
    var body: some View {
        
            List{
                if let series = viewModel.series{
                    //Recorremos la lista de series que se haya actualizado en el viewmodel y la vamos pintando
                    ForEach(series) { serie in
                        
                            //Para cada serie, instancio una celda con todos sus datos
                        SerieRowView(serie: serie)
                        
                    }
                }
                
            }
            .navigationBarTitle("Series \(hero)", displayMode: .inline)
            .id(0)
            
    }
}

struct HeroesSeriesView_Previews: PreviewProvider {
    static var previews: some View {
        HeroesSeriesView(viewModel: HeroSeriesViewModel(testing: true), hero: "Captain Carter")
    }
}
