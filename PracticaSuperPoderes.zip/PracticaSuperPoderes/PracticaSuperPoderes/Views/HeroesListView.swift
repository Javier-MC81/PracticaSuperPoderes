//
//  ContentView.swift
//  PracticaSuperPoderes
//
//  Created by JAVIER MORENO CARRERO on 27/3/23.
//

import SwiftUI

struct HeroesListView: View {
    //Esperamos algún cambio en el publicador creado en el viewmodel para actualizar la vista
    @StateObject var viewModel : RootViewModel
    
    
    var body: some View {
        NavigationView {
            List{
                //Podremos recargar una nueva lista en cuanto la lista de héroes del viewmodel tenga una actualización
                if let heros = viewModel.heros{
                    ForEach(heros) { hero in
                        NavigationLink {
                            //Cargamos la tabla de las series del héroes en el que se hace tap
                            //Ir a las series del heroe
                            HeroesSeriesView(viewModel: HeroSeriesViewModel(hero: hero), hero: hero.name)
                        } label: {
                            //Cargamos una celda diseñada para mostrar los datos del héroe
                            HeroeRowView(hero: hero)
                        }
                    }
                }
                
            }
            .navigationTitle("Lista de heroes")
            .id(0)
            
        }
        
        
    }
}

struct HeroesListView_Previews: PreviewProvider {
    static var previews: some View {
        HeroesListView(viewModel: RootViewModel(testing: true))
            
    }
}
