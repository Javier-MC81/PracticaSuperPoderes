//
//  RootView.swift
//  PracticaSuperPoderes
//
//  Created by JAVIER MORENO CARRERO on 2/4/23.
//

import SwiftUI

struct RootView: View {
    @EnvironmentObject var rootViewModel: RootViewModel
    
    var body: some View {
        
        switch rootViewModel.status {
        case .loading:
            LoadingView()
        case .loaded:
            HeroesListView(viewModel: rootViewModel)
        }
    }
}

struct RootView_Previews: PreviewProvider {
    static var previews: some View {
        RootView()
            .environmentObject(RootViewModel())
    }
}
