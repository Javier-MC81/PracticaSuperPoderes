//
//  HeroeRowView.swift
//  PracticaSuperPoderes
//
//  Created by JAVIER MORENO CARRERO on 27/3/23.
//

import SwiftUI

struct HeroeRowView: View {
    //Necesito un héroe para diseñar su celda
    var hero: Result
    
    var body: some View {
        
        VStack{
            //Desempaqueto la foto y creo la cadena del url
            if let thumb = hero.thumbnail?.path, let thumb2 = hero.thumbnail?.thumbnailExtension {
                
                AsyncImage(url: URL(string: "\(thumb).\(thumb2)")) { Image in
                    Image
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .padding([.trailing,.leading],30)
                        .opacity(0.8)
                        .id(0)
                        
                } placeholder: {
                    Text("Cargando foto...")
                }
                .padding()
                Text("\(hero.name)")
                    .font(.title)
                    .bold()
                    .id(1)
            }


        }
     }
}

struct HeroeRowView_Previews: PreviewProvider {
    static var previews: some View {
        HeroeRowView(hero: Result(id: 01, name: "Hit-Monkey", description: "", modified: "2022-05-03T11:41:04-0400", thumbnail: Thumbnail(path: "http://i.annihil.us/u/prod/marvel/i/mg/6/30/4ce69c2246c21", thumbnailExtension: .jpg)))
    }
}
