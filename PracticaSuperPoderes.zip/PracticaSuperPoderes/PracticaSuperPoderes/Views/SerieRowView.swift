//
//  SerieRowView.swift
//  PracticaSuperPoderes
//
//  Created by JAVIER MORENO CARRERO on 29/3/23.
//

import SwiftUI

struct SerieRowView: View {
    
    var serie: ResultSeries
    
    var body: some View {
        
        ZStack {
            
            VStack{
                //Desempaqueto la foto y creo la cadena del url
                if let thumb = serie.thumbnail?.path, let thumb2 = serie.thumbnail?.thumbnailExtension {
                    
                    AsyncImage(url: URL(string: "\(thumb).\(thumb2)")) { Image in
                        Image
                            .resizable()
                            .frame(width:400,height: 550)
                            .aspectRatio(contentMode: .fit)
                            .cornerRadius(20)
                            .padding([.trailing,.leading],30)
                            .opacity(0.6)
                            .id(0)
                        
                    } placeholder: {
                        Text("Cargando foto...")
                    }
                    .padding(5)
                    
                    Text("\(serie.description ?? "")")
                        .font(.caption)
                        .padding([.leading,.trailing],50)
                        .id(1)
                }
            }
            Text("\(serie.title)")
                .font(.title)
                .bold()
                .padding([.leading,.trailing],50)
                .id(2)
        }
     }
}


struct SerieRowView_Previews: PreviewProvider {
    static var previews: some View {
        SerieRowView(serie: ResultSeries(id: 34322, title: "Captain Carter (2022)", description: "WOMAN OUT OF TIME? A reality where Agent Peggy Carter took the Super-Soldier Serum is turned upside down when the World War II hero is pulled from the ice where she was lost in action decades before. Peggy struggles to find her footing in a modern world that’s gotten a lot more complicated – cities are louder, technology is smarter and enemies wear friendly faces. Everyone with an agenda wants Captain Carter on their side, but what does Peggy want? And will she have time to figure it out when mysterious forces are already gunning for her? Prolific comics creator and designer Jamie McKelvie teams with rising star Marika Cresta to tell an unforgettable Captain Carter story for a modern age.", startYear: 2022, endYear: 2022, modified: "2022-08-11T14:02:37-0400", thumbnail: Thumbnail(path: "http://i.annihil.us/u/prod/marvel/i/mg/b/40/image_not_available", thumbnailExtension: .jpg)))
    }
}
