//
//  Apliclient.swift
//  PracticaSuperPoderes
//
//  Created by JAVIER MORENO CARRERO on 27/3/23.
//

import Foundation
let server = "http://gateway.marvel.com"

struct HTTPMethods {
    static let get = "GET"
    static let content = "application/json"
}
enum keys: String {
    case ts = "1"
    case apiKey = "4a0923acfe91399aeb6f46ed9191c341"
    case hash = "436e126ec9c88a3886912706aa9e885d"
    case orderBy = "-modified"
    
}
enum endpoints : String {

    case herosList = "/v1/public/characters"

}

struct ApiClient {
    
    //lista de heroes
    func getSessionHeros() -> URLRequest{
        let urlcad : String = "\(server)\(endpoints.herosList.rawValue)?ts=\(keys.ts.rawValue)&apikey=\(keys.apiKey.rawValue)&hash=\(keys.hash.rawValue)&orderBy=\(keys.orderBy.rawValue)"
        var request : URLRequest = URLRequest(url: URL(string: urlcad)!)
        request.httpMethod = HTTPMethods.get
        request.addValue(HTTPMethods.content, forHTTPHeaderField: "Content-type")
        
        return request
    }
    
}
struct ApiClientSeries {
    
    //lista de series
    //Meto como parámetro de entrada el héroe que se ha pulsado y hacemos la llamada con su id
    func getSessionSeries(hero: Result) -> URLRequest{
        var url: String = ""
        
        if let id = hero.id {
            
            let urlcad : String = "\(server)\(endpoints.herosList.rawValue)/\(id )/series?ts=\(keys.ts.rawValue)&apikey=\(keys.apiKey.rawValue)&hash=\(keys.hash.rawValue)&orderBy=\(keys.orderBy.rawValue)"
            url = urlcad
        }
        
        var request : URLRequest = URLRequest(url: URL(string: url)!)
        request.httpMethod = HTTPMethods.get
        request.addValue(HTTPMethods.content, forHTTPHeaderField: "Content-type")
        
        return request
    }
}

