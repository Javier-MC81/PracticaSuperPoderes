//
//  PracticaSuperPoderesApp.swift
//  PracticaSuperPoderes
//
//  Created by JAVIER MORENO CARRERO on 27/3/23.
//

import SwiftUI

@main
struct PracticaSuperPoderesApp: App {
    
    //@StateObject var heroViewModel = ViewModelHeros()
    @StateObject var rootViewModel = RootViewModel()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(rootViewModel)
            //HeroesListView(viewModel: ViewModelHeros(testing: false))
                
        }
    }
}


