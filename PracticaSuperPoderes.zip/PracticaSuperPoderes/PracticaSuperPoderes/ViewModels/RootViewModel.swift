//
//  LoadingViewModel.swift
//  PracticaSuperPoderes
//
//  Created by JAVIER MORENO CARRERO on 2/4/23.
//

import Foundation
import Combine

final class RootViewModel: ObservableObject {
    
    @Published var status: Status = Status.loading
    @Published var heros: [Result]?
    var suscriptors = Set<AnyCancellable>()
   
    init(testing:Bool = false){
        if (testing){
            getHerosTesting() //Para el diseño del preview. Muy útil
        } else{
            getHeros()
        }
    }
    
    func getHeros(){
        
        //creo el publicador
        URLSession.shared
            .dataTaskPublisher(for: ApiClient().getSessionHeros())
            .tryMap{
                guard let response = $0.response as? HTTPURLResponse,
                      response.statusCode == 200 else{
                    throw URLError(.badServerResponse)
                }
                //TODO OK
                return $0.data
                
            }
        //OPERADORES PARA TRANSFORMAR LA RESPUESTA
        //Decodificamos el modelo Welcome que nos proporciona Marvel
            .decode(type: Welcome.self, decoder: JSONDecoder())
        //Obtengo el array de héroes de tipo Result que está dentro de la respuesta única
            .tryMap({ welcome in
                return welcome.data?.results
            })
            .receive(on: DispatchQueue.main)
            .sink { completion in
                switch completion{
                case .failure:
                    print("Error en la carga de héroes")
                case .finished:
                    self.status = Status.loaded
                    print("Carga completa")
                }
            } receiveValue: { data in
                //Si el completion es exitoso,actualizamos el array de héroes para que todos los suscriptores reciban el aviso del cambio
                self.heros = data
            }
            .store(in: &suscriptors)
        
        
    }
    func getHerosTesting(){
        let hero1 = Result(id: 01, name: "Hit-Monkey", description: "", modified: "2022-05-03T11:41:04-0400", thumbnail: Thumbnail(path: "http://i.annihil.us/u/prod/marvel/i/mg/6/30/4ce69c2246c21.jpg", thumbnailExtension: .jpg))
        let hero2 = Result(id: 01, name: "Hit-Monkey", description: "", modified: "2022-05-03T11:41:04-0400", thumbnail: Thumbnail(path: "http://i.annihil.us/u/prod/marvel/i/mg/6/30/4ce69c2246c21.jpg", thumbnailExtension: .jpg))
        let hero3 = Result(id: 01, name: "Hit-Monkey", description: "", modified: "2022-05-03T11:41:04-0400", thumbnail: Thumbnail(path: "http://i.annihil.us/u/prod/marvel/i/mg/6/30/4ce69c2246c21.jpg", thumbnailExtension: .jpg))
        let hero4 = Result(id: 01, name: "Hit-Monkey", description: "", modified: "2022-05-03T11:41:04-0400", thumbnail: Thumbnail(path: "http://i.annihil.us/u/prod/marvel/i/mg/6/30/4ce69c2246c21.jpg", thumbnailExtension: .jpg))
        
        self.heros = [hero1, hero2, hero3, hero4]
      
    }
}
