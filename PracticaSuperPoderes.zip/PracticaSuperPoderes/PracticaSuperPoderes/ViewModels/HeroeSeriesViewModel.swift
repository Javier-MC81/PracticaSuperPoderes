//
//  HeroeSeriesViewModel.swift
//  PracticaSuperPoderes
//
//  Created by JAVIER MORENO CARRERO on 28/3/23.
//

import Foundation
import Combine

final class HeroSeriesViewModel: ObservableObject{
    
    
    @Published var series: [ResultSeries]?
    var hero : Result?
    
    var suscriptors2 = Set<AnyCancellable>()
    
    init(hero: Result){
        self.hero = hero
        getSeries(hero: hero)
    }
    
    init(testing:Bool = false){
        
        
        if (testing){
            getSeriesTesting()
        } else{
            getSeries(hero: self.hero!)
        }
    }
    func getSeries(hero: Result){
        //creo el publicador
        URLSession.shared
            .dataTaskPublisher(for: ApiClientSeries().getSessionSeries(hero: hero))
            .tryMap{
                guard let response = $0.response as? HTTPURLResponse,
                      response.statusCode == 200 else{
                    throw URLError(.badServerResponse)
                }
                //TODO OK
                return $0.data

            }
        //OPERADORES PARA TRANSFORMAR LA RESPUESTA
        //Decodificamos el modelo Empty que nos proporciona Marvel
            .decode(type: Empty.self, decoder: JSONDecoder())
        //Obtengo el array de series de tipo ResultSeries que está dentro de la respuesta única

            .tryMap({ empty in
                return empty.data.results
            })
            .receive(on: DispatchQueue.main)
            .sink { completion in
                switch completion{
                case .failure:
                    print("Error en la carga de las series")
                case .finished:
                    //self.status = .loaded
                    print("Carga completa de series")
                }
            } receiveValue: { data in
                //Si el completion es exitoso,actualizamos el array de series para que todos los suscriptores reciban el aviso del cambio
                self.series = data
            }
            .store(in: &suscriptors2)

    }
    func getSeriesTesting(){//Para el diseño en el preview "en caliente" . Muy útil.
        let serie1 = ResultSeries(id: 34322, title: "Captain Carter (2022)", description: "WOMAN OUT OF TIME? A reality where Agent Peggy Carter took the Super-Soldier Serum is turned upside down when the World War II hero is pulled from the ice where she was lost in action decades before.", startYear: 2022, endYear: 2022, modified: "2022-08-11T14:02:37-0400", thumbnail: Thumbnail(path: "http://i.annihil.us/u/prod/marvel/i/mg/b/40/image_not_available", thumbnailExtension: .jpg))
        let serie2 = ResultSeries(id: 34322, title: "Captain Carter (2022)", description: "WOMAN OUT OF TIME? A reality where Agent Peggy Carter took the Super-Soldier Serum is turned upside down when the World War II hero is pulled from the ice where she was lost in action decades before.", startYear: 2022, endYear: 2022, modified: "2022-08-11T14:02:37-0400", thumbnail: Thumbnail(path: "http://i.annihil.us/u/prod/marvel/i/mg/b/40/image_not_available", thumbnailExtension: .jpg))
        let serie3 = ResultSeries(id: 34322, title: "Captain Carter (2022)", description: "WOMAN OUT OF TIME? A reality where Agent Peggy Carter took the Super-Soldier Serum is turned upside down when the World War II hero is pulled from the ice where she was lost in action decades before.", startYear: 2022, endYear: 2022, modified: "2022-08-11T14:02:37-0400", thumbnail: Thumbnail(path: "http://i.annihil.us/u/prod/marvel/i/mg/b/40/image_not_available", thumbnailExtension: .jpg))
        let serie4 = ResultSeries(id: 34322, title: "Captain Carter (2022)", description: "WOMAN OUT OF TIME? A reality where Agent Peggy Carter took the Super-Soldier Serum is turned upside down when the World War II hero is pulled from the ice where she was lost in action decades before.", startYear: 2022, endYear: 2022, modified: "2022-08-11T14:02:37-0400", thumbnail: Thumbnail(path: "http://i.annihil.us/u/prod/marvel/i/mg/b/40/image_not_available", thumbnailExtension: .jpg))
        
        self.series = [serie1,serie2,serie3,serie4]
      
    }
}
