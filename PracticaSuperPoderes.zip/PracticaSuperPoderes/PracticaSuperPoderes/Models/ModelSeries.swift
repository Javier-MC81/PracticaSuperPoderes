//
//  ModelSeries.swift
//  PracticaSuperPoderes
//
//  Created by JAVIER MORENO CARRERO on 28/3/23.

// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let empty = try? JSONDecoder().decode(Empty.self, from: jsonData)

import Foundation

//Modelos de la respuesta a la llamada para solicitar las series de un héroe

// MARK: - Empty
struct Empty: Codable {
    let code: Int
    let status, copyright, attributionText, attributionHTML: String
    let etag: String
    let data: DataClassSeries
}

// MARK: - DataClass
struct DataClassSeries: Codable {
    let offset, limit, total, count: Int
    let results: [ResultSeries]?
}

// MARK: - Result
struct ResultSeries: Codable, Identifiable {
    let id: Int
    let title: String
    let description: String?
    let startYear, endYear: Int?
    let modified: String?
    let thumbnail: Thumbnail?

}

