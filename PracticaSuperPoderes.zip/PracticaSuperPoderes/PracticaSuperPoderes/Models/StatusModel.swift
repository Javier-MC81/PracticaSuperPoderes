//
//  StatusModel.swift
//  PracticaSuperPoderes
//
//  Created by JAVIER MORENO CARRERO on 2/4/23.
//

import Foundation

//Mis estados de la navegacion Principal
enum Status {
    case loading, loaded
}
